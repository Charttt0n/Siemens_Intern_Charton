set pagination off
set confirm off
set remotetimeout 20
target remote /tmp/w7bench-qep_7d26/gdb.sock
tbreak main
continue
set {unsigned int}0x40000000 = 0
set {unsigned int}0x40000008 = 0xffffffff
set {unsigned int}0x40000000 = 1
tbreak *0x00004dd4
continue
printf "W7_BEFORE_TICKS=%u\n", 0xffffffff - *(unsigned int*)0x40000004
set $before = *(unsigned int*)0x40000004
tbreak *0x00004c20
continue
printf "W7_TOTAL_TICKS=%u\n", 0xffffffff - *(unsigned int*)0x40000004
printf "W7_VERIFY_TICKS=%u\n", $before - *(unsigned int*)0x40000004
info registers pc sp
print boot_image
print boot_status
detach
quit
