set pagination off
set confirm off
set remotetimeout 20
target remote /tmp/w7bench-xu16m2w0/gdb.sock
tbreak main
continue
set {unsigned int}0x40000000 = 0
set {unsigned int}0x40000008 = 0xffffffff
set {unsigned int}0x40000000 = 1
tbreak *0x00000dd8
continue
printf "W7_BEFORE_TICKS=%u\n", 0xffffffff - *(unsigned int*)0x40000004
set $before = *(unsigned int*)0x40000004
tbreak *0x00000c48
continue
printf "W7_TOTAL_TICKS=%u\n", 0xffffffff - *(unsigned int*)0x40000004
printf "W7_VERIFY_TICKS=%u\n", $before - *(unsigned int*)0x40000004
info registers pc sp
print boot_image
print boot_status
detach
quit
