QEMU run artifacts. Relative evidence paths refer to their run directory. Absolute paths in original command logs describe the recording host. No lab private key.
