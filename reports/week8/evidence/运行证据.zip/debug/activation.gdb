set pagination off
set confirm off
target remote 127.0.0.1:56328
tbreak update_activate
continue
set $ctx = (update_context*)$r0
printf "W7_CFG_PENDING=%u,%u\n", *(unsigned int*)0x203f201c, *(unsigned int*)0x203f301c
printf "W7_CFG_STAGE=%u,%u\n", *(unsigned int*)0x203f2020, *(unsigned int*)0x203f3020
printf "W7_OLD_ACTIVE=%u\n", $ctx->record.active_slot
backtrace
finish
printf "W7_ACTIVATE_RESULT=%u\n", $r0
printf "W7_NEW_ACTIVE=%u\n", $ctx->record.active_slot
print $ctx->record
detach
quit
