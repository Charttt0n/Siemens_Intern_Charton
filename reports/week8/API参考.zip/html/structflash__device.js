var structflash__device =
[
    [ "memory", "structflash__device.html#aea11afcad599b0bb0eeee5df6b5fd444", null ]
];