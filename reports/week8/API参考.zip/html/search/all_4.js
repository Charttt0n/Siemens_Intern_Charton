var searchData=
[
  ['erase_0',['erase',['../structmeta__flash__ops.html#ae9a2cd6ef6b92a5c5463ab221b0afd23',1,'meta_flash_ops::erase'],['../structupdate__flash__ops.html#a51ab669ca55a682940a313dff059ed81',1,'update_flash_ops::erase']]],
  ['error_1',['error',['../structmeta__record.html#a344e5b5c53de8d7558b0263d9b248a20',1,'meta_record']]],
  ['expected_2',['expected',['../structupdate__context.html#a4189714a4b1439ac3531b7458cf7e651',1,'update_context']]],
  ['expected_5flength_3',['expected_length',['../structmeta__record.html#a5e2032a2b5aa2ef17918f605ba48c908',1,'meta_record']]]
];
