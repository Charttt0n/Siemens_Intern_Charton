var searchData=
[
  ['dev_0',['dev',['../structupdate__context.html#ae6262a325e9c6e15e0a65376d0cfc17f',1,'update_context']]]
];
