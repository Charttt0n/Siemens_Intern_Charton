var searchData=
[
  ['offset_0',['offset',['../structflash__partition.html#afccb0f2acd713c1d55366732c306a586',1,'flash_partition']]],
  ['ops_1',['ops',['../structupdate__context.html#a03e622803b8137e41dfb7040249d125d',1,'update_context']]]
];
