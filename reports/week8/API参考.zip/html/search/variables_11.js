var searchData=
[
  ['window_5fms_0',['window_ms',['../structcfg__record.html#aafea0bff4534708e5e62e3c5cc2a5899',1,'cfg_record']]],
  ['write_1',['write',['../structymodem__io.html#a2f0df1b3742aa8789bb7673c0be3366a',1,'ymodem_io::write'],['../structymodem__sink.html#aef0eb12f59f5b2371e8e0f4d1afe0482',1,'ymodem_sink::write']]]
];
