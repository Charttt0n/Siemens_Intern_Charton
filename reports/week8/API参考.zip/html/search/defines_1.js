var searchData=
[
  ['cfg_5fdefault_5fwindow_5fms_0',['CFG_DEFAULT_WINDOW_MS',['../boot__config_8h.html#abf4d506751f9a0bad78e199aee35450b',1,'boot_config.h']]],
  ['cfg_5fmagic_1',['CFG_MAGIC',['../boot__config_8h.html#a9388aa5b7f8109151eed907f120da512',1,'boot_config.h']]],
  ['cfg_5fmarker_2',['CFG_MARKER',['../boot__config_8h.html#a8f792d71f9f0c8ed7bf301dab6c6e238',1,'boot_config.h']]],
  ['cfg_5fmax_5fwindow_5fms_3',['CFG_MAX_WINDOW_MS',['../boot__config_8h.html#ab7eafffb4d37e71e4e8e9c896bb6cb11',1,'boot_config.h']]],
  ['cfg_5fmin_5fwindow_5fms_4',['CFG_MIN_WINDOW_MS',['../boot__config_8h.html#a0e6cc2f79ff68246dafd10dd4e9725cf',1,'boot_config.h']]],
  ['cfg_5fpage_5fbase_5',['CFG_PAGE_BASE',['../boot__config_8h.html#ac7de255321988b8257a5ac42efcfb542',1,'boot_config.h']]],
  ['cfg_5frecord_5fsize_6',['CFG_RECORD_SIZE',['../boot__config_8h.html#a54ad7ef69107baefb196be2841fe8772',1,'boot_config.h']]],
  ['cfg_5fschema_7',['CFG_SCHEMA',['../boot__config_8h.html#ab53b6f6e55538726b39ab766820f91b6',1,'boot_config.h']]],
  ['cfg_5ftrial_5farmed_8',['CFG_TRIAL_ARMED',['../boot__config_8h.html#acb3a8e2b2f0611aac6ddcf5f8b8ae52f',1,'boot_config.h']]],
  ['cfg_5ftrial_5flaunched_9',['CFG_TRIAL_LAUNCHED',['../boot__config_8h.html#a430ec5637c91e34e5269d731c9b38366',1,'boot_config.h']]],
  ['cfg_5ftrial_5fnone_10',['CFG_TRIAL_NONE',['../boot__config_8h.html#a6278669780c3932e3c57590aae252e5b',1,'boot_config.h']]]
];
