var searchData=
[
  ['watchdog_5fbase_0',['WATCHDOG_BASE',['../watchdog_8h.html#a2b03c881c009285dc481d31c08796df4',1,'watchdog.h']]],
  ['watchdog_5fclk_5fhz_1',['WATCHDOG_CLK_HZ',['../watchdog_8h.html#a16292667b13cd2b7dd97ae8c3ab4f31a',1,'watchdog.h']]]
];
