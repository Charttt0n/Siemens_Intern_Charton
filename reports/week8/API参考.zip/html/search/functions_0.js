var searchData=
[
  ['board_5fclock_5fhz_0',['board_clock_hz',['../board_8h.html#a5584f6a73a7c9ae003ed9179ae7a31ef',1,'board.h']]],
  ['board_5finit_1',['board_init',['../board_8h.html#a916f2adc2080b4fe88034086d107a8dc',1,'board.h']]],
  ['boot_5fverify_5floaded_2',['boot_verify_loaded',['../image_8h.html#a111e1ee72bda1a578694ac6f3e08318c',1,'image.h']]]
];
