var searchData=
[
  ['image_5fresult_0',['image_result',['../image_8h.html#a203ab5e27cfaf07e45be5609f4017ad0',1,'image.h']]]
];
