var searchData=
[
  ['secure_5fresult_0',['secure_result',['../secure__image_8h.html#a11e768fa0f2726826ccd8e95e2776f47',1,'secure_image.h']]]
];
