var searchData=
[
  ['last_5fconfirmed_5fslot_0',['last_confirmed_slot',['../structcfg__record.html#aef57d23c1526624a37f0690d43f34869',1,'cfg_record']]],
  ['load_1',['load',['../structimage__info.html#a843f222136f9f1fd4f559bc4096ae3df',1,'image_info']]]
];
