var searchData=
[
  ['ymodem_5fname_5fmax_0',['YMODEM_NAME_MAX',['../ymodem_8h.html#ade552fe6598b696c346e3dd7c9e63bde',1,'ymodem.h']]],
  ['ymodem_5fpacket_5fmax_1',['YMODEM_PACKET_MAX',['../ymodem_8h.html#acea16f7768e6585796499db8f3db8ccd',1,'ymodem.h']]]
];
