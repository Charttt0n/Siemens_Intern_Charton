var indexSectionsWithContent =
{
  0: "abcdefgilmnoprstuvwy",
  1: "cfimuy",
  2: "abcfistuwy",
  3: "bcfimstuwy",
  4: "abcdefglmnoprstuvw",
  5: "cfimsuy",
  6: "cfimsuy",
  7: "acfimsuwy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros"
};

