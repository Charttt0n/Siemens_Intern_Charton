var searchData=
[
  ['timebase_5finit_0',['timebase_init',['../timebase_8h.html#ad945459f4f708e9d852390669268f231',1,'timebase.h']]],
  ['timebase_5fms_1',['timebase_ms',['../timebase_8h.html#a6b28e98b4f7759e37498036ca092ec44',1,'timebase.h']]],
  ['trial_5factivate_2',['trial_activate',['../control_8h.html#a412f87d2af9ec56740e977cfadd64427',1,'control.h']]]
];
