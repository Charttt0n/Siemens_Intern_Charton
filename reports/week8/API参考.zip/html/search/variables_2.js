var searchData=
[
  ['candidate_5fversion_0',['candidate_version',['../structmeta__record.html#a82c3d1cee68c22e98afd64ce0f644cd5',1,'meta_record']]],
  ['context_1',['context',['../structmeta__flash__ops.html#a8adea36fc075c28b6d4fde816d872f6c',1,'meta_flash_ops::context'],['../structupdate__flash__ops.html#af0ae86eafd264598319be39a43a0081d',1,'update_flash_ops::context'],['../structymodem__io.html#a09d74d71e6d93ae9f62b8550c649b530',1,'ymodem_io::context'],['../structymodem__sink.html#a2701d2ea8321484400af53baca5f5c97',1,'ymodem_sink::context']]],
  ['crc_2',['crc',['../structimage__info.html#a82e56ea46e64faca98a8a17c67fd1c77',1,'image_info::crc'],['../structmeta__record.html#ab34d435063ae13716e61d658bee2f23e',1,'meta_record::crc'],['../structcfg__record.html#ab707984b880e0a3a517a78e5970cd918',1,'cfg_record::crc']]]
];
