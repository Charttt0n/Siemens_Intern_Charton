var searchData=
[
  ['generation_0',['generation',['../structmeta__record.html#a23c5ec20cbee381335c0d63e6448adc7',1,'meta_record::generation'],['../structcfg__record.html#ae75df66d04a144b71decc4cc5ea6b19d',1,'cfg_record::generation']]]
];
