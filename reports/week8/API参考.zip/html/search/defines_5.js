var searchData=
[
  ['secure_5fmax_5fpayload_0',['SECURE_MAX_PAYLOAD',['../secure__image_8h.html#aaf0ab8943d45360199a1cd8e113b5439',1,'secure_image.h']]],
  ['sig_5flength_1',['SIG_LENGTH',['../secure__image_8h.html#ab44a5fcf414b4a4006b5b53a3fec0f76',1,'secure_image.h']]],
  ['sig_5fmagic_2',['SIG_MAGIC',['../secure__image_8h.html#ac47b9c82560d34bb55eb5486a66940ac',1,'secure_image.h']]],
  ['sig_5ftrailer_5fsize_3',['SIG_TRAILER_SIZE',['../secure__image_8h.html#abeb431e8957e2477e3687b486a7ff245',1,'secure_image.h']]],
  ['sig_5ftype_5frsa2048_5fsha256_5fpkcs1v15_4',['SIG_TYPE_RSA2048_SHA256_PKCS1V15',['../secure__image_8h.html#a91995a8e6ab66325c85f9dfa9c11252b',1,'secure_image.h']]]
];
