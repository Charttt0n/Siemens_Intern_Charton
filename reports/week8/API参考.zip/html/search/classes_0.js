var searchData=
[
  ['cfg_5frecord_0',['cfg_record',['../structcfg__record.html',1,'']]]
];
