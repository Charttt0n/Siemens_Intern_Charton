var searchData=
[
  ['uart_5frx_5fcount_0',['uart_rx_count',['../uart_8h.html#a6810503b1d4a4ea23326884b4efe5782',1,'uart.h']]],
  ['uart_5frx_5fdropped_1',['uart_rx_dropped',['../uart_8h.html#aac1685a2e8d00bf5ef9cbf4977c9a1ea',1,'uart.h']]],
  ['uart_5frx_5foverruns_2',['uart_rx_overruns',['../uart_8h.html#a25fbae9ae4339ee3bfba69f6425179b2',1,'uart.h']]]
];
