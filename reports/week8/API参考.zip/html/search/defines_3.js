var searchData=
[
  ['image_5fformat_0',['IMAGE_FORMAT',['../image_8h.html#af939ccfbcd7b94459c7d13479380b507',1,'image.h']]],
  ['image_5fheader_5fsize_1',['IMAGE_HEADER_SIZE',['../image_8h.html#a4f4d2c1b9854b8e45aee1e29f8d1ad43',1,'image.h']]],
  ['image_5fmagic_2',['IMAGE_MAGIC',['../image_8h.html#a771d7c22e8d14cf13638f67dc24354af',1,'image.h']]]
];
