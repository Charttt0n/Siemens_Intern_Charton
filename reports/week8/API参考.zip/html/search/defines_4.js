var searchData=
[
  ['meta_5fmagic_0',['META_MAGIC',['../boot__meta_8h.html#ae2c98529d01b83b976af715a4d2bcff4',1,'boot_meta.h']]],
  ['meta_5fmarker_1',['META_MARKER',['../boot__meta_8h.html#a1a8a8321e9e3dd68f1f541a6dffa3b9b',1,'boot_meta.h']]],
  ['meta_5fmax_5fpayload_2',['META_MAX_PAYLOAD',['../boot__meta_8h.html#ae4054a016cf11b56e3a57b3cecbef06f',1,'boot_meta.h']]],
  ['meta_5fmin_5fpayload_3',['META_MIN_PAYLOAD',['../boot__meta_8h.html#a0522e2c0b0f56a440257bf6901fa0adb',1,'boot_meta.h']]],
  ['meta_5fpage_5fcount_4',['META_PAGE_COUNT',['../boot__meta_8h.html#a2a710d3d5ba8d5f7c31c296741529297',1,'boot_meta.h']]],
  ['meta_5fpage_5fsize_5',['META_PAGE_SIZE',['../boot__meta_8h.html#afbc9a20985a2d4bd5641eb55dc76da56',1,'boot_meta.h']]],
  ['meta_5frecord_5fsize_6',['META_RECORD_SIZE',['../boot__meta_8h.html#a986a60e834acb15a3fa4ca0b4db385d5',1,'boot_meta.h']]],
  ['meta_5fschema_7',['META_SCHEMA',['../boot__meta_8h.html#a2de2f26900fc2686b0a31f2b4c573ca9',1,'boot_meta.h']]],
  ['meta_5fslot_5fnone_8',['META_SLOT_NONE',['../boot__meta_8h.html#a2d0240031c0fcdc8454dbb69e371dfce',1,'boot_meta.h']]]
];
