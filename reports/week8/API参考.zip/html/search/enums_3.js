var searchData=
[
  ['meta_5fresult_0',['meta_result',['../boot__meta_8h.html#a6144f7cd027edeb8e9d674e0a8b94e18',1,'boot_meta.h']]],
  ['meta_5fstate_1',['meta_state',['../boot__meta_8h.html#a3aea5c479b2b2eb67f4bdd3b37200f95',1,'boot_meta.h']]]
];
