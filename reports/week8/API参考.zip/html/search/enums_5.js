var searchData=
[
  ['update_5fresult_0',['update_result',['../update_8h.html#afff1de1b3cf1ca749e9f159f601dc4ce',1,'update.h']]]
];
