var searchData=
[
  ['secure_5finit_0',['secure_init',['../secure__image_8h.html#a52437d1bc551e9593271976b5adb762e',1,'secure_image.h']]],
  ['secure_5fvalidate_5fslot_1',['secure_validate_slot',['../secure__image_8h.html#a477805f90d4e086296fb2697bef6e141',1,'secure_image.h']]]
];
