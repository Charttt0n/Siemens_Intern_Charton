var searchData=
[
  ['name_0',['name',['../structymodem__stats.html#af2455f3ab82114c6498dbd5b1de84978',1,'ymodem_stats']]],
  ['no_5fprogress_5ftimeout_5fms_1',['no_progress_timeout_ms',['../structymodem__config.html#a62ffe41b5bf35adc1e069172d4aca588',1,'ymodem_config']]],
  ['now_5fms_2',['now_ms',['../structymodem__io.html#a40e607da8ea6f98fa1236c4e80f369b8',1,'ymodem_io']]]
];
