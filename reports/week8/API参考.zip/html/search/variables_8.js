var searchData=
[
  ['magic_0',['magic',['../structmeta__record.html#a191e75859e0e7293a11860d24e6b52f0',1,'meta_record::magic'],['../structcfg__record.html#a5a12b78e8cb5d0f2aa397481125a2dcc',1,'cfg_record::magic']]],
  ['marker_1',['marker',['../structmeta__record.html#a32a2e31b8e5248bd998d32e6e4617931',1,'meta_record::marker'],['../structcfg__record.html#a5f159dbae406f00a78f784473eaf4436',1,'cfg_record::marker']]],
  ['max_5ffile_5fsize_2',['max_file_size',['../structymodem__config.html#aee67974ef9da62be35110540c92461e8',1,'ymodem_config']]],
  ['memory_3',['memory',['../structflash__device.html#aea11afcad599b0bb0eeee5df6b5fd444',1,'flash_device']]],
  ['meta_5fops_4',['meta_ops',['../structupdate__context.html#a9a5b1363b42f732c9a2500be20dee8b6',1,'update_context']]],
  ['msp_5',['msp',['../structimage__info.html#a5f2c5695adfa09ec4afdd1e4c6283caf',1,'image_info']]]
];
