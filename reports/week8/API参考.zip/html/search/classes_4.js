var searchData=
[
  ['update_5fcontext_0',['update_context',['../structupdate__context.html',1,'']]],
  ['update_5fflash_5fops_1',['update_flash_ops',['../structupdate__flash__ops.html',1,'']]]
];
