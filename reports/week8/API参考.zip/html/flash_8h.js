var flash_8h =
[
    [ "flash_partition", "structflash__partition.html", "structflash__partition" ],
    [ "flash_device", "structflash__device.html", "structflash__device" ],
    [ "FLASH_ERASE_SIZE", "flash_8h.html#a7407d0bb0053b539b8144477b446978a", null ],
    [ "FLASH_PROGRAM_SIZE", "flash_8h.html#a081e15cc044cf15654dc1e3adeff4977", null ],
    [ "FLASH_SIM_BASE", "flash_8h.html#a02ec9b2da461072177f37df907890139", null ],
    [ "FLASH_SIZE", "flash_8h.html#ae69620948dea1b76e0ab7843ab719db7", null ],
    [ "flash_partition_id", "flash_8h.html#a861494799dcace65ba7dcea8c3bd53c1", [
      [ "FLASH_BOOT", "flash_8h.html#a861494799dcace65ba7dcea8c3bd53c1aaedec460b52ab9980e4839c30bea755d", null ],
      [ "FLASH_APP", "flash_8h.html#a861494799dcace65ba7dcea8c3bd53c1a99786d24ca2febc54939c007b7a2d04b", null ],
      [ "FLASH_BACKUP", "flash_8h.html#a861494799dcace65ba7dcea8c3bd53c1a2f027a9b9b55e24955740a321769538d", null ],
      [ "FLASH_PARAMS", "flash_8h.html#a861494799dcace65ba7dcea8c3bd53c1abc2dc0f8f319e6f99a1351cbbc78c9f8", null ],
      [ "FLASH_PARTITION_COUNT", "flash_8h.html#a861494799dcace65ba7dcea8c3bd53c1a0c54a650996170322be57e1ae43f9ac7", null ]
    ] ],
    [ "flash_result", "flash_8h.html#ae04bbad743a7d3e67d4edf080be6cbdf", [
      [ "FLASH_OK", "flash_8h.html#ae04bbad743a7d3e67d4edf080be6cbdfaa61fd1fbf9781160f18a474a834723e7", null ],
      [ "FLASH_ARGUMENT", "flash_8h.html#ae04bbad743a7d3e67d4edf080be6cbdfae87039bc9939bc562b5e5078678feaac", null ],
      [ "FLASH_RANGE", "flash_8h.html#ae04bbad743a7d3e67d4edf080be6cbdfa9a628b7b7407d624949fede12c332562", null ],
      [ "FLASH_ALIGNMENT", "flash_8h.html#ae04bbad743a7d3e67d4edf080be6cbdfa72f32c8e92c8fd4b5bab53d935b6621a", null ],
      [ "FLASH_PROTECTED", "flash_8h.html#ae04bbad743a7d3e67d4edf080be6cbdfa505218ce1bbb4ca216dacdf893d7cca0", null ],
      [ "FLASH_NEEDS_ERASE", "flash_8h.html#ae04bbad743a7d3e67d4edf080be6cbdfa7e158546c1655d4454a4fc850a191b9f", null ]
    ] ],
    [ "flash_erase", "flash_8h.html#afb12000c7a68187c602bb63e62e320ea", null ],
    [ "flash_partition_get", "flash_8h.html#a258dff0ff13cb12a30fccfb412a20608", null ],
    [ "flash_program", "flash_8h.html#a7f3be8aac01d27a70bc6518cd5ccb6df", null ],
    [ "flash_read", "flash_8h.html#a49ab602749193431a841cd6aab4eb9a7", null ],
    [ "flash_sim_bind", "flash_8h.html#ad845114a59349b6176434c09d6c14135", null ]
];