var board_8h =
[
    [ "board_clock_hz", "board_8h.html#a5584f6a73a7c9ae003ed9179ae7a31ef", null ],
    [ "board_init", "board_8h.html#a916f2adc2080b4fe88034086d107a8dc", null ]
];