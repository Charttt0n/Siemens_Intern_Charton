var update_8h =
[
    [ "update_flash_ops", "structupdate__flash__ops.html", "structupdate__flash__ops" ],
    [ "update_context", "structupdate__context.html", "structupdate__context" ],
    [ "update_result", "update_8h.html#afff1de1b3cf1ca749e9f159f601dc4ce", [
      [ "UPDATE_OK", "update_8h.html#afff1de1b3cf1ca749e9f159f601dc4ceaba01c4f0b477f5ef6796d095a32779d4", null ],
      [ "UPDATE_IO", "update_8h.html#afff1de1b3cf1ca749e9f159f601dc4cea59acd2e2a033e592f438567a5d64aa8e", null ],
      [ "UPDATE_ARGUMENT", "update_8h.html#afff1de1b3cf1ca749e9f159f601dc4ceaa497fc383f347f016560476ec91b19b9", null ],
      [ "UPDATE_LENGTH", "update_8h.html#afff1de1b3cf1ca749e9f159f601dc4cea6f3113e4770960370b8b1db1d1b64562", null ],
      [ "UPDATE_IMAGE", "update_8h.html#afff1de1b3cf1ca749e9f159f601dc4ceabe61e1737298197b2da7c3bf51199111", null ],
      [ "UPDATE_STATE", "update_8h.html#afff1de1b3cf1ca749e9f159f601dc4cea40f946f5968ac12f21c862cda96c2244", null ],
      [ "UPDATE_ERASE", "update_8h.html#afff1de1b3cf1ca749e9f159f601dc4ceaec3c9c0cac20372bfce114f8de6c04dc", null ],
      [ "UPDATE_WRITE", "update_8h.html#afff1de1b3cf1ca749e9f159f601dc4ceaf7c438a5480c74e88147de3b1f9d13f0", null ],
      [ "UPDATE_META", "update_8h.html#afff1de1b3cf1ca749e9f159f601dc4ceaa3452d50dc0a55d484cea171dba0ffc8", null ],
      [ "UPDATE_ABORTED", "update_8h.html#afff1de1b3cf1ca749e9f159f601dc4ceacfb65372dedaadc9df6a5c9e84473fa5", null ]
    ] ],
    [ "update_activate", "update_8h.html#a3f311a69a5631c38c0d1b703ec90f180", null ],
    [ "update_flash_bind", "update_8h.html#aa49953292e4916caff0e2d13fcfd5657", null ],
    [ "update_prepare", "update_8h.html#a1c068ef66bd4b9ffe1ea745b565ae8e4", null ],
    [ "update_sink_init", "update_8h.html#a623d5b893c3659b1d1028a35c21fafb2", null ]
];