var structupdate__context =
[
    [ "active", "structupdate__context.html#a083ec57fe0e0c12b035aa7479cc36929", null ],
    [ "begun", "structupdate__context.html#a28976903ca9a5150c85e53684aaa5ca5", null ],
    [ "dev", "structupdate__context.html#ae6262a325e9c6e15e0a65376d0cfc17f", null ],
    [ "expected", "structupdate__context.html#a4189714a4b1439ac3531b7458cf7e651", null ],
    [ "failed", "structupdate__context.html#a6301eff8698d69eae02a8541344576d7", null ],
    [ "finished", "structupdate__context.html#aae01ddee35823aea35df24aecd62d52a", null ],
    [ "meta_ops", "structupdate__context.html#a9a5b1363b42f732c9a2500be20dee8b6", null ],
    [ "ops", "structupdate__context.html#a03e622803b8137e41dfb7040249d125d", null ],
    [ "payload_expected", "structupdate__context.html#a4e8100c98047b7ba110c1651e3924653", null ],
    [ "programmed", "structupdate__context.html#ab20c792ba3417b123b30fa5c1e03b19d", null ],
    [ "received", "structupdate__context.html#a9edfc2f2c4d895485b9a7b8846c861b4", null ],
    [ "record", "structupdate__context.html#ae712a712a09172f70d5e7ab01cd3875c", null ],
    [ "stage", "structupdate__context.html#a14b50b7b3504cd48280c074a8a2cd4a9", null ],
    [ "staged", "structupdate__context.html#a3bb658ee6d67ee62248a28f13a513e74", null ],
    [ "target", "structupdate__context.html#a77a75cb1625b8057ba8eb25cc56d6a6f", null ]
];