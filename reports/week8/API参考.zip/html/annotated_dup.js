var annotated_dup =
[
    [ "cfg_record", "structcfg__record.html", "structcfg__record" ],
    [ "flash_device", "structflash__device.html", "structflash__device" ],
    [ "flash_partition", "structflash__partition.html", "structflash__partition" ],
    [ "image_info", "structimage__info.html", "structimage__info" ],
    [ "meta_flash_ops", "structmeta__flash__ops.html", "structmeta__flash__ops" ],
    [ "meta_record", "structmeta__record.html", "structmeta__record" ],
    [ "update_context", "structupdate__context.html", "structupdate__context" ],
    [ "update_flash_ops", "structupdate__flash__ops.html", "structupdate__flash__ops" ],
    [ "ymodem_config", "structymodem__config.html", "structymodem__config" ],
    [ "ymodem_io", "structymodem__io.html", "structymodem__io" ],
    [ "ymodem_sink", "structymodem__sink.html", "structymodem__sink" ],
    [ "ymodem_stats", "structymodem__stats.html", "structymodem__stats" ]
];