var structflash__partition =
[
    [ "offset", "structflash__partition.html#afccb0f2acd713c1d55366732c306a586", null ],
    [ "size", "structflash__partition.html#a6178f778bc1b1dc950858e8c3b7c4b0b", null ]
];