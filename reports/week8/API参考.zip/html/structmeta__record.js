var structmeta__record =
[
    [ "active_slot", "structmeta__record.html#a093af921646e08e8dcf95b4a8490fe8a", null ],
    [ "candidate_version", "structmeta__record.html#a82c3d1cee68c22e98afd64ce0f644cd5", null ],
    [ "crc", "structmeta__record.html#ab34d435063ae13716e61d658bee2f23e", null ],
    [ "error", "structmeta__record.html#a344e5b5c53de8d7558b0263d9b248a20", null ],
    [ "expected_length", "structmeta__record.html#a5e2032a2b5aa2ef17918f605ba48c908", null ],
    [ "generation", "structmeta__record.html#a23c5ec20cbee381335c0d63e6448adc7", null ],
    [ "magic", "structmeta__record.html#a191e75859e0e7293a11860d24e6b52f0", null ],
    [ "marker", "structmeta__record.html#a32a2e31b8e5248bd998d32e6e4617931", null ],
    [ "progress", "structmeta__record.html#ae588933547567f236e7824e529f8c612", null ],
    [ "schema", "structmeta__record.html#aec44a01784cea67476d2baaee5d6db22", null ],
    [ "state", "structmeta__record.html#afaf80221a312e97871d964f261935ea5", null ],
    [ "target_slot", "structmeta__record.html#a7d7bfc1555ee7382102de8dd2d763b21", null ]
];