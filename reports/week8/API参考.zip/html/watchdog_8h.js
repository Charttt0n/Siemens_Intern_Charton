var watchdog_8h =
[
    [ "WATCHDOG_BASE", "watchdog_8h.html#a2b03c881c009285dc481d31c08796df4", null ],
    [ "WATCHDOG_CLK_HZ", "watchdog_8h.html#a16292667b13cd2b7dd97ae8c3ab4f31a", null ],
    [ "watchdog_kick", "watchdog_8h.html#a5638303bd176a87c7722e1b9fba03e10", null ],
    [ "watchdog_running", "watchdog_8h.html#a1892acbae0e8ee31f8414f3a47c08c18", null ],
    [ "watchdog_start", "watchdog_8h.html#a3b8ffdee1a3168c23580c43f900bcdd1", null ],
    [ "watchdog_stop", "watchdog_8h.html#a284d9a9542a5fa2c84bf4a70bfbc80aa", null ]
];