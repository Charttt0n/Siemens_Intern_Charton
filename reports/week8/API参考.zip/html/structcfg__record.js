var structcfg__record =
[
    [ "auto_boot", "structcfg__record.html#a35b69f31476847a7f6916357c78a6343", null ],
    [ "crc", "structcfg__record.html#ab707984b880e0a3a517a78e5970cd918", null ],
    [ "generation", "structcfg__record.html#ae75df66d04a144b71decc4cc5ea6b19d", null ],
    [ "last_confirmed_slot", "structcfg__record.html#aef57d23c1526624a37f0690d43f34869", null ],
    [ "magic", "structcfg__record.html#a5a12b78e8cb5d0f2aa397481125a2dcc", null ],
    [ "marker", "structcfg__record.html#a5f159dbae406f00a78f784473eaf4436", null ],
    [ "reserved", "structcfg__record.html#a5d77be522d11c1f70fa5024f67206075", null ],
    [ "schema", "structcfg__record.html#a44dbdba6664d537630fe836be742bed5", null ],
    [ "trial_pending", "structcfg__record.html#aa3f44a08936339b7209355f8a3ed786a", null ],
    [ "trial_slot", "structcfg__record.html#a5767e4b7b9e1e7d8d405b379e437a9b6", null ],
    [ "trial_stage", "structcfg__record.html#a98d0434def02d6d135bd7624b71df861", null ],
    [ "window_ms", "structcfg__record.html#aafea0bff4534708e5e62e3c5cc2a5899", null ]
];