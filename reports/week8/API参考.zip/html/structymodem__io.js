var structymodem__io =
[
    [ "context", "structymodem__io.html#a09d74d71e6d93ae9f62b8550c649b530", null ],
    [ "now_ms", "structymodem__io.html#a40e607da8ea6f98fa1236c4e80f369b8", null ],
    [ "read", "structymodem__io.html#ac1ec66b5b552e8bc60e4b867773e2967", null ],
    [ "write", "structymodem__io.html#a2f0df1b3742aa8789bb7673c0be3366a", null ]
];