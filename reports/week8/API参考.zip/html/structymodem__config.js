var structymodem__config =
[
    [ "max_file_size", "structymodem__config.html#aee67974ef9da62be35110540c92461e8", null ],
    [ "no_progress_timeout_ms", "structymodem__config.html#a62ffe41b5bf35adc1e069172d4aca588", null ],
    [ "retry_limit", "structymodem__config.html#abca80f87957f9ebd9a5070a72d415078", null ],
    [ "timeout_ms", "structymodem__config.html#a87c7329934cd1d91903d247995fc95b7", null ]
];