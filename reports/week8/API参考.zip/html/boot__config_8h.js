var boot__config_8h =
[
    [ "cfg_record", "structcfg__record.html", "structcfg__record" ],
    [ "CFG_DEFAULT_WINDOW_MS", "boot__config_8h.html#abf4d506751f9a0bad78e199aee35450b", null ],
    [ "CFG_MAGIC", "boot__config_8h.html#a9388aa5b7f8109151eed907f120da512", null ],
    [ "CFG_MARKER", "boot__config_8h.html#a8f792d71f9f0c8ed7bf301dab6c6e238", null ],
    [ "CFG_MAX_WINDOW_MS", "boot__config_8h.html#ab7eafffb4d37e71e4e8e9c896bb6cb11", null ],
    [ "CFG_MIN_WINDOW_MS", "boot__config_8h.html#a0e6cc2f79ff68246dafd10dd4e9725cf", null ],
    [ "CFG_PAGE_BASE", "boot__config_8h.html#ac7de255321988b8257a5ac42efcfb542", null ],
    [ "CFG_RECORD_SIZE", "boot__config_8h.html#a54ad7ef69107baefb196be2841fe8772", null ],
    [ "CFG_SCHEMA", "boot__config_8h.html#ab53b6f6e55538726b39ab766820f91b6", null ],
    [ "CFG_TRIAL_ARMED", "boot__config_8h.html#acb3a8e2b2f0611aac6ddcf5f8b8ae52f", null ],
    [ "CFG_TRIAL_LAUNCHED", "boot__config_8h.html#a430ec5637c91e34e5269d731c9b38366", null ],
    [ "CFG_TRIAL_NONE", "boot__config_8h.html#a6278669780c3932e3c57590aae252e5b", null ],
    [ "cfg_result", "boot__config_8h.html#af8cbe95fcf333c8bdeac7faa8889b9b5", [
      [ "CFG_OK", "boot__config_8h.html#af8cbe95fcf333c8bdeac7faa8889b9b5a597122fba97b8e62767f0f40588021d2", null ],
      [ "CFG_IO", "boot__config_8h.html#af8cbe95fcf333c8bdeac7faa8889b9b5ac0823def5fc65daa5bb719d326e633a1", null ],
      [ "CFG_NO_RECORD", "boot__config_8h.html#af8cbe95fcf333c8bdeac7faa8889b9b5a13f2e9de9e8e7390b57488e2e37c8c95", null ],
      [ "CFG_ARGUMENT", "boot__config_8h.html#af8cbe95fcf333c8bdeac7faa8889b9b5a6b07295583648699ef666f9242cfdebf", null ],
      [ "CFG_VERIFY", "boot__config_8h.html#af8cbe95fcf333c8bdeac7faa8889b9b5abb071b6358d1448c74ec6fa512179b1c", null ],
      [ "CFG_AMBIGUOUS", "boot__config_8h.html#af8cbe95fcf333c8bdeac7faa8889b9b5a01f7f764e6c1f3261e8afab84d841fb4", null ]
    ] ],
    [ "cfg_commit", "boot__config_8h.html#a447ab838d6e320c593010dc057809eba", null ],
    [ "cfg_defaults", "boot__config_8h.html#a2ac237a7c41cde898f4eaa969a6a24fe", null ],
    [ "cfg_init", "boot__config_8h.html#a2e1cb29a243a9c66a1c23cb4a706ec53", null ],
    [ "cfg_read", "boot__config_8h.html#a0fd3c3c1b9645a63ee916c8a164e1869", null ]
];