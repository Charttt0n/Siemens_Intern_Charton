var boot__meta_8h =
[
    [ "meta_record", "structmeta__record.html", "structmeta__record" ],
    [ "meta_flash_ops", "structmeta__flash__ops.html", "structmeta__flash__ops" ],
    [ "META_MAGIC", "boot__meta_8h.html#ae2c98529d01b83b976af715a4d2bcff4", null ],
    [ "META_MARKER", "boot__meta_8h.html#a1a8a8321e9e3dd68f1f541a6dffa3b9b", null ],
    [ "META_MAX_PAYLOAD", "boot__meta_8h.html#ae4054a016cf11b56e3a57b3cecbef06f", null ],
    [ "META_MIN_PAYLOAD", "boot__meta_8h.html#a0522e2c0b0f56a440257bf6901fa0adb", null ],
    [ "META_PAGE_COUNT", "boot__meta_8h.html#a2a710d3d5ba8d5f7c31c296741529297", null ],
    [ "META_PAGE_SIZE", "boot__meta_8h.html#afbc9a20985a2d4bd5641eb55dc76da56", null ],
    [ "META_RECORD_SIZE", "boot__meta_8h.html#a986a60e834acb15a3fa4ca0b4db385d5", null ],
    [ "META_SCHEMA", "boot__meta_8h.html#a2de2f26900fc2686b0a31f2b4c573ca9", null ],
    [ "META_SLOT_NONE", "boot__meta_8h.html#a2d0240031c0fcdc8454dbb69e371dfce", null ],
    [ "meta_result", "boot__meta_8h.html#a6144f7cd027edeb8e9d674e0a8b94e18", [
      [ "META_OK", "boot__meta_8h.html#a6144f7cd027edeb8e9d674e0a8b94e18adad0426f54963071402012dd5b325caa", null ],
      [ "META_IO", "boot__meta_8h.html#a6144f7cd027edeb8e9d674e0a8b94e18ae7a93470b88c0f7702b7f875aea1912c", null ],
      [ "META_NO_RECORD", "boot__meta_8h.html#a6144f7cd027edeb8e9d674e0a8b94e18a805d33fe3407e9693f7c869ebbd38b66", null ],
      [ "META_RECOVERY_REQUIRED", "boot__meta_8h.html#a6144f7cd027edeb8e9d674e0a8b94e18af877b00397343c1d9ad88db1d2c377e0", null ],
      [ "META_ARGUMENT", "boot__meta_8h.html#a6144f7cd027edeb8e9d674e0a8b94e18a6575098a290804947b0b3dca31c1c417", null ],
      [ "META_VERIFY", "boot__meta_8h.html#a6144f7cd027edeb8e9d674e0a8b94e18ad593777677f727e770a71a4e34f013a4", null ],
      [ "META_AMBIGUOUS", "boot__meta_8h.html#a6144f7cd027edeb8e9d674e0a8b94e18a6e0ce6d77bc29625ad3c34c4b422ef9f", null ],
      [ "META_CRC", "boot__meta_8h.html#a6144f7cd027edeb8e9d674e0a8b94e18afeffe2a37b09f466b74d1568bc79255a", null ],
      [ "META_FIELD", "boot__meta_8h.html#a6144f7cd027edeb8e9d674e0a8b94e18aa263e62ed10765c25d446c609d3d2711", null ],
      [ "META_MARKER_MISSING", "boot__meta_8h.html#a6144f7cd027edeb8e9d674e0a8b94e18af0b3df7b784308a3dce067bcb2d25d5f", null ]
    ] ],
    [ "meta_state", "boot__meta_8h.html#a3aea5c479b2b2eb67f4bdd3b37200f95", [
      [ "META_STATE_IDLE", "boot__meta_8h.html#a3aea5c479b2b2eb67f4bdd3b37200f95a0585dc38e2e2c316a81ee42f6740019f", null ],
      [ "META_STATE_RECEIVING", "boot__meta_8h.html#a3aea5c479b2b2eb67f4bdd3b37200f95a00ae78c5b3912ccf0c41ab5a19432dff", null ],
      [ "META_STATE_VERIFYING", "boot__meta_8h.html#a3aea5c479b2b2eb67f4bdd3b37200f95afc18174f09ecfe60ec182c0d38560d8e", null ],
      [ "META_STATE_READY", "boot__meta_8h.html#a3aea5c479b2b2eb67f4bdd3b37200f95abc4875e37bf762964e4b43f3b2e7fcb2", null ],
      [ "META_STATE_FAILED", "boot__meta_8h.html#a3aea5c479b2b2eb67f4bdd3b37200f95aaea14dbb024b54751b874ba4e75d0ece", null ]
    ] ],
    [ "meta_commit", "boot__meta_8h.html#a3bbabe938a1db28a2e37c6680dfed672", null ],
    [ "meta_decode", "boot__meta_8h.html#acde1caae25bd93dcccdac7bce4d463f2", null ],
    [ "meta_encode", "boot__meta_8h.html#a3e601c1663a42ecb3a7839b8f2766c9e", null ],
    [ "meta_flash_bind", "boot__meta_8h.html#ac1f1ff57d61a697f13cad81cffa3b64a", null ],
    [ "meta_init", "boot__meta_8h.html#aba21a36e6dac687b1007fc19984f421e", null ],
    [ "meta_read", "boot__meta_8h.html#a80fc27a7d56db9074d0672a65985f305", null ]
];