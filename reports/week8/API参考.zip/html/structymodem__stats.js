var structymodem__stats =
[
    [ "blocks", "structymodem__stats.html#a3d5a60e4522849aa3008f106c60c2aba", null ],
    [ "name", "structymodem__stats.html#af2455f3ab82114c6498dbd5b1de84978", null ],
    [ "received", "structymodem__stats.html#ada593390f2c581ada0dccd58af5e55af", null ],
    [ "retries", "structymodem__stats.html#a012830c3ef3f2324de35d897ccae5f79", null ],
    [ "size", "structymodem__stats.html#a63425453d8907e010422d0cbf5440aa6", null ]
];