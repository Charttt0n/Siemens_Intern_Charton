var image_8h =
[
    [ "image_info", "structimage__info.html", "structimage__info" ],
    [ "APP_EXEC_BASE", "image_8h.html#acefb753d9811fda3e658cb6006fbf51a", null ],
    [ "APP_EXEC_SIZE", "image_8h.html#aead50bfe3931090448373032e807aec8", null ],
    [ "APP_RAM_BASE", "image_8h.html#a5d1a7e335d463a510cc736a2068d564e", null ],
    [ "APP_RAM_TOP", "image_8h.html#a5031e1506a4b2c51896dde9ac58ccf7e", null ],
    [ "APP_VECTOR_SIZE", "image_8h.html#a901f922d97268ef361292a27d980c4e6", null ],
    [ "IMAGE_FORMAT", "image_8h.html#af939ccfbcd7b94459c7d13479380b507", null ],
    [ "IMAGE_HEADER_SIZE", "image_8h.html#a4f4d2c1b9854b8e45aee1e29f8d1ad43", null ],
    [ "IMAGE_MAGIC", "image_8h.html#a771d7c22e8d14cf13638f67dc24354af", null ],
    [ "image_result", "image_8h.html#a203ab5e27cfaf07e45be5609f4017ad0", [
      [ "IMAGE_OK", "image_8h.html#a203ab5e27cfaf07e45be5609f4017ad0a50ced5f9ea19c6245fa00acbdb2902e1", null ],
      [ "IMAGE_IO", "image_8h.html#a203ab5e27cfaf07e45be5609f4017ad0a6d287faffd5a5762c0112546364a6a5f", null ],
      [ "IMAGE_FORMAT_ERROR", "image_8h.html#a203ab5e27cfaf07e45be5609f4017ad0a4db7f6c33d0cc333c34045ee952c652f", null ],
      [ "IMAGE_HEADER_CRC", "image_8h.html#a203ab5e27cfaf07e45be5609f4017ad0aeb218d1d1fff86d9f2b313271569ba44", null ],
      [ "IMAGE_LENGTH", "image_8h.html#a203ab5e27cfaf07e45be5609f4017ad0a79b676660248d8fc25e18b740a3374ae", null ],
      [ "IMAGE_ADDRESS", "image_8h.html#a203ab5e27cfaf07e45be5609f4017ad0adda50e56c59acd7775bbf5f1dcea67d0", null ],
      [ "IMAGE_PAYLOAD_CRC", "image_8h.html#a203ab5e27cfaf07e45be5609f4017ad0ae226d29657772f62d8d5b8eef35be5ae", null ],
      [ "IMAGE_VECTOR", "image_8h.html#a203ab5e27cfaf07e45be5609f4017ad0a732cc0932fa908bd1ee29c6c15ae2f8e", null ],
      [ "IMAGE_COPY_CRC", "image_8h.html#a203ab5e27cfaf07e45be5609f4017ad0a5cb98a03dc6dc3696328fd93a66ba3a8", null ],
      [ "IMAGE_SLOT", "image_8h.html#a203ab5e27cfaf07e45be5609f4017ad0a1ae85b0cb396d06384f12841f2fd9280", null ]
    ] ],
    [ "boot_verify_loaded", "image_8h.html#a111e1ee72bda1a578694ac6f3e08318c", null ],
    [ "image_load", "image_8h.html#a9ee6494f61db959cc6fa9f7ea8797308", null ],
    [ "image_load_slot", "image_8h.html#a5ddccc082a7b6678a08a7078b1ae6abf", null ],
    [ "image_slot_supported", "image_8h.html#a7a7e3ee050f9b18d9ff8d8544e920f0e", null ],
    [ "image_validate", "image_8h.html#a96eddaba67a57dc0b09c0f57822cb5ca", null ],
    [ "image_validate_slot", "image_8h.html#a6e44d11b8517b6125147668bdc66efac", null ]
];