var crc32_8h =
[
    [ "crc32", "crc32_8h.html#a6197244985df42d431b5c0e316bc0fa0", null ],
    [ "crc32_update", "crc32_8h.html#a079e37f61ebd985848e08ffb3dd1cb7d", null ]
];