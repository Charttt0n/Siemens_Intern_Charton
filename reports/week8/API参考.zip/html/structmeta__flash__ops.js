var structmeta__flash__ops =
[
    [ "context", "structmeta__flash__ops.html#a8adea36fc075c28b6d4fde816d872f6c", null ],
    [ "erase", "structmeta__flash__ops.html#ae9a2cd6ef6b92a5c5463ab221b0afd23", null ],
    [ "program", "structmeta__flash__ops.html#a15e28bf17d1f7d98db9ed6b44df44ede", null ],
    [ "read", "structmeta__flash__ops.html#ada985b8bd32a1c00f076c173a4a629df", null ]
];