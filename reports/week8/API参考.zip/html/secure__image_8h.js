var secure__image_8h =
[
    [ "SECURE_MAX_PAYLOAD", "secure__image_8h.html#aaf0ab8943d45360199a1cd8e113b5439", null ],
    [ "SIG_LENGTH", "secure__image_8h.html#ab44a5fcf414b4a4006b5b53a3fec0f76", null ],
    [ "SIG_MAGIC", "secure__image_8h.html#ac47b9c82560d34bb55eb5486a66940ac", null ],
    [ "SIG_TRAILER_SIZE", "secure__image_8h.html#abeb431e8957e2477e3687b486a7ff245", null ],
    [ "SIG_TYPE_RSA2048_SHA256_PKCS1V15", "secure__image_8h.html#a91995a8e6ab66325c85f9dfa9c11252b", null ],
    [ "secure_result", "secure__image_8h.html#a11e768fa0f2726826ccd8e95e2776f47", [
      [ "SECURE_OK", "secure__image_8h.html#a11e768fa0f2726826ccd8e95e2776f47a1b0cfe47f41409e57eb9aef75de864e4", null ],
      [ "SECURE_IO", "secure__image_8h.html#a11e768fa0f2726826ccd8e95e2776f47a8ca4260ec421bdc92479f5acfc3a58aa", null ],
      [ "SECURE_IMAGE", "secure__image_8h.html#a11e768fa0f2726826ccd8e95e2776f47a61c23d1731a7e9bb7b124452ef398573", null ],
      [ "SECURE_TRAILER", "secure__image_8h.html#a11e768fa0f2726826ccd8e95e2776f47a145c99e2cf22284e22dc0c2a8904c9be", null ],
      [ "SECURE_UNSIGNED", "secure__image_8h.html#a11e768fa0f2726826ccd8e95e2776f47a80ec809e90bef080b0d64d2bedcd1865", null ],
      [ "SECURE_TYPE", "secure__image_8h.html#a11e768fa0f2726826ccd8e95e2776f47aa9b8d8b737bd242f00514ee86dcf41ad", null ],
      [ "SECURE_HASH", "secure__image_8h.html#a11e768fa0f2726826ccd8e95e2776f47a3a6618f1a5ac746626843895122593a3", null ],
      [ "SECURE_SIGNATURE", "secure__image_8h.html#a11e768fa0f2726826ccd8e95e2776f47a973d66d1fe3cb61e32e70db9c18e255d", null ],
      [ "SECURE_KEY", "secure__image_8h.html#a11e768fa0f2726826ccd8e95e2776f47ae9377e75483d25b758af723a86b0c43f", null ],
      [ "SECURE_INIT", "secure__image_8h.html#a11e768fa0f2726826ccd8e95e2776f47a51a70d5191c98329eee7ecb0a46f524b", null ]
    ] ],
    [ "secure_init", "secure__image_8h.html#a52437d1bc551e9593271976b5adb762e", null ],
    [ "secure_validate_slot", "secure__image_8h.html#a477805f90d4e086296fb2697bef6e141", null ]
];