var structupdate__flash__ops =
[
    [ "context", "structupdate__flash__ops.html#af0ae86eafd264598319be39a43a0081d", null ],
    [ "erase", "structupdate__flash__ops.html#a51ab669ca55a682940a313dff059ed81", null ],
    [ "program", "structupdate__flash__ops.html#a0880e48923342ee2a0eed9cd642868d2", null ],
    [ "read", "structupdate__flash__ops.html#a94cb9667d0f5f8d47bbdc0a35afe689c", null ]
];