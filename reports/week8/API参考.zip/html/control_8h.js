var control_8h =
[
    [ "config_parse_u32", "control_8h.html#aa14c1e664da8a83e6960997bcb2a53a2", null ],
    [ "config_set", "control_8h.html#a73bb2fa806f6945a9a21a54fc622da52", null ],
    [ "trial_activate", "control_8h.html#a412f87d2af9ec56740e977cfadd64427", null ]
];